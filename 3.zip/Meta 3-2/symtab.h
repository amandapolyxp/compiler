/* Amanda Menezes 2017124788 */
/* Pedro Meira 2019223208 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "semantics.h"

void criaTabelas(node* current);

void addLocalVar(node* nodeAux,list_func * funcAux);
